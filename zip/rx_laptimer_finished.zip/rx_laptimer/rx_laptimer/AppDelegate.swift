//
//  AppDelegate.swift
//  rx_laptimer
//
//  Created by Marin Todorov on 2/15/16.
//  Copyright © 2016 Underplot ltd. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

}